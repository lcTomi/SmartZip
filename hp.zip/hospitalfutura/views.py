from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import redirect # para poder redireccionar a otra pagina
#from django.contrib import messages # para manejar mensaje de login correcto o incorrecto
from django import forms

import mysql.connector
config = {
  'user': 'root',
  'password': '',
  'host': 'localhost',
  'database': 'hospitalapp',
  'raise_on_warnings': True
}


def index (request):
    return render(request, 'index.html', {})

def login (request):
    if request.method == 'POST':

        mail = request.POST.get('mail')
        password= request.POST.get('password')
        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
        sql = "SELECT * FROM usuarios WHERE mail = '"+mail+"' AND password = '" +password+"'"
        cursor.execute(sql)
        usuario = cursor.fetchall()
        conexion.commit()
        conexion.close()

        
        if usuario != []:
            return redirect ('admin')
        else:
            return redirect ('login')

    return render(request, 'login.html', {})

def admin (request):
    return render(request, 'admin.html', {})

def usuarios (request):

    ## consulta
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM usuarios inner join roles on usuarios.rol=roles.id_roles')
    usuarios = cursor.fetchall()
    conexion.commit()
    conexion.close()
    ## consulta
    
    if request.method == 'POST':
        
        id_eliminar= request.POST.get('id_eliminar')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
        
        id_usuario= id_eliminar
        eliminar_usuario = ("DELETE FROM usuarios WHERE `usuarios`.`id_usuario` = '%s'" % id_usuario)

        # Inserto
        cursor.execute(eliminar_usuario)

        conexion.commit()
        return redirect ('usuarios') 

        

    return render(request, 'usuarios.html', {
        'usuarios' : usuarios,

    })

def productos (request):

    ## consulta
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM productos')
    productos = cursor.fetchall()
    conexion.commit()
    conexion.close()
    ## consulta

    if request.method == 'POST':
        
        id_eliminar= request.POST.get('id_eliminar')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
        
        id_producto= id_eliminar
        eliminar_producto = ("DELETE FROM productos WHERE `productos`.`id_producto` = '%s'" % id_producto)

        # Inserto
        cursor.execute(eliminar_producto)

        conexion.commit()
        return redirect ('productos')        

    return render(request, 'productos.html', {
        'productos' : productos,

    })

def pacientes (request):

    ## consulta
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    #cursor.execute('SELECT * FROM pacientes')
    cursor.execute('SELECT * FROM pacientes inner join tipo_dieta on pacientes.id_tipo_dieta=tipo_dieta.id_tipo_dieta inner join categoria_hospital on pacientes.id_categoria_hospital=categoria_hospital.id_categoria_hospital')

    pacientes = cursor.fetchall()
     
    conexion.commit()
    conexion.close()
    ## consulta

    if request.method == 'POST':
        
        id_eliminar= request.POST.get('id_eliminar')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
        
        id_paciente= id_eliminar
        eliminar_paciente = ("DELETE FROM pacientes WHERE `pacientes`.`id_paciente` = '%s'" % id_paciente)

        # Inserto
        cursor.execute(eliminar_paciente)

        conexion.commit()
        return redirect ('pacientes')  
        

    return render(request, 'pacientes.html', {
        'pacientes' : pacientes,

    })

def dietas (request):

    ## consulta
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM tipo_dieta')

    dietas = cursor.fetchall()
     
    conexion.commit()
    conexion.close()
    ## consulta

    if request.method == 'POST':
        
        id_eliminar= request.POST.get('id_eliminar')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
        
        id_dieta= id_eliminar
        eliminar_dieta = ("DELETE FROM tipo_dieta WHERE `tipo_dieta`.`id_tipo_dieta` = '%s'" % id_dieta)

        # Inserto
        cursor.execute(eliminar_dieta)

        conexion.commit()
        return redirect ('dietas')  
        

    return render(request, 'dietas.html', {
        'dietas' : dietas,

    })

def hospital (request):

    ## consulta
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM categoria_hospital')

    hospital = cursor.fetchall()
     
    conexion.commit()
    conexion.close()
    ## consulta

    if request.method == 'POST':
        
        id_eliminar= request.POST.get('id_eliminar')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
        
        id_hospital= id_eliminar
        eliminar_hospital = ("DELETE FROM categoria_hospital WHERE `categoria_hospital`.`id_categoria_hospital` = '%s'" % id_hospital)

        # Inserto
        cursor.execute(eliminar_hospital)

        conexion.commit()
        return redirect ('hospital')  
        

    return render(request, 'hospital.html', {
        'hospital' : hospital,

    })

def dieta_alta (request):

    if request.method == 'POST':
        
        tipo = request.POST.get('tipo')
        detalles= request.POST.get('detalles')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
            
        add_usuario = ("INSERT INTO tipo_dieta "
                    "(tipo, detalles) "
                    "VALUES (%s, %s)")

        data_usuario = (tipo, detalles)

        # Inserto
        cursor.execute(add_usuario, data_usuario)

        conexion.commit()
        return redirect ('dietas')


    
    
    return render(request, 'dieta_alta.html', {})

def hospital_alta (request):

    if request.method == 'POST':
        
        categoria = request.POST.get('categoria')
        detalles= request.POST.get('detalles')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
            
        add_usuario = ("INSERT INTO categoria_hospital "
                    "(categoria, detalles) "
                    "VALUES (%s, %s)")

        data_usuario = (categoria, detalles)

        # Inserto
        cursor.execute(add_usuario, data_usuario)

        conexion.commit()
        return redirect ('hospital')


    
    
    return render(request, 'hospital_alta.html', {})

def producto_alta (request):

    if request.method == 'POST':
        
        producto = request.POST.get('producto')
        cantidad= request.POST.get('cantidad')
        detalle= request.POST.get('detalle')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
            
        add_usuario = ("INSERT INTO productos "
                    "(producto, cantidad, detalle) "
                    "VALUES (%s, %s, %s)")

        data_usuario = (producto, cantidad, detalle)

        # Inserto
        cursor.execute(add_usuario, data_usuario)

        conexion.commit()
        return redirect ('productos')


    
    
    return render(request, 'producto_alta.html', {})

def paciente_alta (request):
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM tipo_dieta')
    dietas = cursor.fetchall()
    cursor.execute('SELECT * FROM categoria_hospital')
    categoria = cursor.fetchall()
    conexion.commit()

    if request.method == 'POST':
        
        nombre = request.POST.get('nombre')
        apellido= request.POST.get('apellido')
        diagnostico= request.POST.get('diagnostico')
        sexo = request.POST.get('sexo')
        id_tipo_dieta= request.POST.get('id_tipo_dieta')
        id_categoria_hospital= request.POST.get('id_categoria_hospital')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
            
        add_usuario = ("INSERT INTO pacientes "
                    "(nombre, apellido, diagnostico, sexo, id_tipo_dieta, id_categoria_hospital) "
                    "VALUES (%s, %s, %s, %s, %s, %s)")

        data_usuario = (nombre, apellido, diagnostico, sexo, id_tipo_dieta, id_categoria_hospital)

        # Inserto
        cursor.execute(add_usuario, data_usuario)

        conexion.commit()
        return redirect ('pacientes')


    
    
    return render(request, 'paciente_alta.html', {
        'dietas' : dietas,
        'categoria' : categoria,
        })

def usuario_alta (request):

    if request.method == 'POST':
        
        nombre= request.POST.get('nombre')
        apellido= request.POST.get('apellido')
        mail= request.POST.get('mail')
        password= request.POST.get('password')
        telefono= request.POST.get('telefono')
        rol= request.POST.get('rol')

        conexion = mysql.connector.connect(**config)
        cursor = conexion.cursor()
            
        add_usuario = ("INSERT INTO usuarios "
                    "(nombre, apellido, mail, password, telefono, rol) "
                    "VALUES (%s, %s, %s, %s, %s, %s)")

        data_usuario = (nombre, apellido, mail, password, telefono, rol)

        # Inserto
        cursor.execute(add_usuario, data_usuario)

        conexion.commit()
        return redirect ('usuarios')


    
    
    return render(request, 'usuario_alta.html', {})

def usuario_editar (request):
    
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM usuarios')
    usuarios = cursor.fetchall()
    conexion.commit()
    
    if request.method == 'POST':
        tabla_e= request.POST.get('tabla-e')
        nombre= request.POST.get('nombre')
        apellido= request.POST.get('apellido')
        mail= request.POST.get('mail')
        password= request.POST.get('password')
        telefono= request.POST.get('telefono')
        rol= request.POST.get('rol')

        nombre_up = ("UPDATE usuarios SET nombre = %s WHERE id_usuario = %s")
        if not nombre:
            None
        else:
            cursor.execute(nombre_up, (nombre, tabla_e))
            
        apellido_up = ("UPDATE usuarios SET apellido = %s WHERE id_usuario = %s")
        if not apellido:
            None
        else:
            cursor.execute(apellido_up, (apellido, tabla_e))
            
        mail_up = ("UPDATE usuarios SET mail = %s WHERE id_usuario = %s")
        if not mail:
            None
        else:
            cursor.execute(mail_up, (mail, tabla_e))
            
        password_up = ("UPDATE usuarios SET password = %s WHERE id_usuario = %s")
        if not password:
            None
        else:
            cursor.execute(password_up, (password, tabla_e))
            
        telefono_up = ("UPDATE usuarios SET telefono = %s WHERE id_usuario = %s")
        if not telefono:
            None
        else:
            cursor.execute(telefono_up, (telefono, tabla_e))
            
        rol_up = ("UPDATE usuarios SET rol = %s WHERE id_usuario = %s")
        if not rol:
            None
        else:
            cursor.execute(rol_up, (rol, tabla_e))

        conexion.commit()
        return redirect ('usuarios')

    #UPDATE set
    
    return render(request, 'usuario_editar.html', {
        'usuarios' : usuarios,
    })

def producto_editar (request):
    
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM productos')
    productos = cursor.fetchall()
    conexion.commit()
    
    if request.method == 'POST':
        tabla_e = request.POST.get('tabla-e')
        producto = request.POST.get('producto')
        cantidad= request.POST.get('cantidad')
        detalle= request.POST.get('detalle')
            
        producto_up = ("UPDATE productos SET producto = %s WHERE id_producto = %s")
        if not producto:
            None
        else:
            cursor.execute(producto_up, (producto, tabla_e))
            
        cantidad_up = ("UPDATE productos SET cantidad = %s WHERE id_producto = %s")
        if not cantidad:
            None
        else:
            cursor.execute(cantidad_up, (cantidad, tabla_e))
            
        detalle_up = ("UPDATE productos SET detalle = %s WHERE id_producto = %s")
        if not detalle:
            None
        else:
            cursor.execute(detalle_up, (detalle, tabla_e))

        conexion.commit()
        return redirect ('productos')
    
    return render(request, 'producto_editar.html', {
        'productos' : productos,
    })

def paciente_editar (request):
    
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM pacientes')
    pacientes = cursor.fetchall()
    cursor.execute('SELECT * FROM tipo_dieta')
    dietas = cursor.fetchall()
    cursor.execute('SELECT * FROM categoria_hospital')
    categoria = cursor.fetchall()
    conexion.commit()
    
    if request.method == 'POST':
        tabla_e= request.POST.get('tabla-e')
        nombre = request.POST.get('nombre')
        apellido= request.POST.get('apellido')
        diagnostico= request.POST.get('diagnostico')
        sexo = request.POST.get('sexo')
        id_tipo_dieta= request.POST.get('id_tipo_dieta')
        id_categoria_hospital= request.POST.get('id_categoria_hospital')

        nombre_up = ("UPDATE pacientes SET nombre = %s WHERE id_paciente = %s")
        if not nombre:
            None
        else:
            cursor.execute(nombre_up, (nombre, tabla_e))
            
        apellido_up = ("UPDATE pacientes SET apellido = %s WHERE id_paciente = %s")
        if not apellido:
            None
        else:
            cursor.execute(apellido_up, (apellido, tabla_e))
            
        diagnostico_up = ("UPDATE pacientes SET diagnostico = %s WHERE id_paciente = %s")
        if not diagnostico:
            None
        else:
            cursor.execute(diagnostico_up, (diagnostico, tabla_e))
            
        sexo_up = ("UPDATE pacientes SET sexo = %s WHERE id_paciente = %s")
        if not sexo:
            None
        else:
            cursor.execute(sexo_up, (sexo, tabla_e))
            
        id_tipo_dieta_up = ("UPDATE pacientes SET id_tipo_dieta = %s WHERE id_paciente = %s")
        if not id_tipo_dieta:
            None
        else:
            cursor.execute(id_tipo_dieta_up, (id_tipo_dieta, tabla_e))
            
        id_categoria_hospital_up = ("UPDATE pacientes SET id_categoria_hospital = %s WHERE id_paciente = %s")
        if not id_categoria_hospital:
            None
        else:
            cursor.execute(id_categoria_hospital_up, (id_categoria_hospital, tabla_e))

        conexion.commit()
        return redirect ('pacientes')

    #UPDATE set
    
    return render(request, 'paciente_editar.html', {
        'pacientes' : pacientes,
        'dietas' : dietas,
        'categoria' : categoria,
    })

def dieta_editar (request):
    
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM tipo_dieta')
    dietas = cursor.fetchall()
    conexion.commit()
    
    if request.method == 'POST':
        tabla_e = request.POST.get('tabla-e')
        tipo = request.POST.get('tipo')
        detalles= request.POST.get('detalles')
            
        tipo_up = ("UPDATE tipo_dieta SET tipo = %s WHERE id_tipo_dieta = %s")
        if not tipo:
            None
        else:
            cursor.execute(tipo_up, (tipo, tabla_e))
            
        detalles_up = ("UPDATE tipo_dieta SET detalles = %s WHERE id_tipo_dieta = %s")
        if not detalles:
            None
        else:
            cursor.execute(detalles_up, (detalles, tabla_e))

        conexion.commit()
        return redirect ('dietas')
    
    return render(request, 'dieta_editar.html', {
        'dietas' : dietas,
    })

def hospital_editar (request):
    
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM categoria_hospital')
    hospital = cursor.fetchall()
    conexion.commit()
    
    if request.method == 'POST':
        tabla_e = request.POST.get('tabla-e')
        categoria = request.POST.get('categoria')
        detalles= request.POST.get('detalles')
            
        categoria_up = ("UPDATE categoria_hospital SET categoria = %s WHERE id_categoria_hospital = %s")
        if not categoria:
            None
        else:
            cursor.execute(categoria_up, (categoria, tabla_e))
            
        detalles_up = ("UPDATE categoria_hospital SET detalles = %s WHERE id_categoria_hospital = %s")
        if not detalles:
            None
        else:
            cursor.execute(detalles_up, (detalles, tabla_e))

        conexion.commit()
        return redirect ('hospital')
    
    return render(request, 'hospital_editar.html', {
        'hospital' : hospital,
    })

def paciente_detalle (request):
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM pacientes inner join tipo_dieta on pacientes.id_tipo_dieta=tipo_dieta.id_tipo_dieta inner join categoria_hospital on pacientes.id_categoria_hospital=categoria_hospital.id_categoria_hospital inner join sexo on pacientes.sexo=sexo.id_sexo')
    pacientes = cursor.fetchall()
    conexion.commit()
    conexion.close()

    return render(request, 'paciente_detalle.html', {
        'pacientes' : pacientes,
    })

def consulta (request):
    
    conexion = mysql.connector.connect(**config)  
    cursor = conexion.cursor()
    cursor.execute('SELECT * FROM usuarios')
    usuarios = cursor.fetchall()
    conexion.commit()
    
    if request.method == 'POST':
        tabla_e= request.POST.get('tabla-e')
        nombre= request.POST.get('nombre')
        apellido= request.POST.get('apellido')
            
        nombre_up = ("UPDATE usuarios SET nombre = %s WHERE id_usuario = %s")
        if not nombre:
            None
        else:
            cursor.execute(nombre_up, (nombre, tabla_e))

        apellido_up = ("UPDATE usuarios SET apellido = %s WHERE id_usuario = %s")
        cursor.execute(apellido_up, (apellido, tabla_e))

        conexion.commit()
        return redirect ('usuarios')

    #UPDATE set
    
    return render(request, 'usuario_editar.html', {
        'usuarios' : usuarios,
    })