
from django.contrib import admin
from django.urls import path

from.import views

urlpatterns = [
    path('', views.index, name= 'index'),
    path('login', views.login, name= 'login'),
    path('admin', views.admin, name= 'admin'),
    path('usuarios', views.usuarios, name= 'usuarios'),
    path('usuario_alta', views.usuario_alta, name= 'usuario_alta'),
    path('usuario_editar', views.usuario_editar, name= 'usuario_editar'),
    path('productos', views.productos, name= 'productos'),
    path('producto_alta', views.producto_alta, name= 'producto_alta'),
    path('producto_editar', views.producto_editar, name= 'producto_editar'),
    path('pacientes', views.pacientes, name= 'pacientes'),
    path('paciente_alta', views.paciente_alta, name= 'paciente_alta'),
    path('paciente_editar', views.paciente_editar, name= 'paciente_editar'),
    path('paciente_detalle', views.paciente_detalle, name= 'paciente_detalle'),
    path('dietas', views.dietas, name= 'dietas'),
    path('dieta_alta', views.dieta_alta, name= 'dieta_alta'),
    path('dieta_editar', views.dieta_editar, name= 'dieta_editar'),
    path('hospital', views.hospital, name= 'hospital'),
    path('hospital_alta', views.hospital_alta, name= 'hospital_alta'),
    path('hospital_editar', views.hospital_editar, name= 'hospital_editar'),
    path('consulta', views.consulta, name= 'consulta'),
    #path('admin/', admin.site.urls),
]

